#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun May 12 21:27:11 2019

@author: frankzhou
"""
import time

t = 0
while True:
    time.sleep(1)
    t+=1
    import game
    game.pygame.quit()
print("the end")