#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue May  7 16:25:13 2019

@author: frankzhou
"""

import os
os.system("Game.py")