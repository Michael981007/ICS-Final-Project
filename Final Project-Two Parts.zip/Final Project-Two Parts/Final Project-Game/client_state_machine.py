"""
Created on Sun Apr  5 00:00:32 2015

@author: zhengzhang
"""
from chat_utils import *
import json
import os
##########################Encrypt and Decrypt############################
key = "Frankey"
def vigenere_encrypt(plain, key):
    #pad key
    len1 = len(plain)
    len2 = len(key)
    if len2 < len1:
        t = len1//len2 #times
        r = len1%len2 #remainer
        key = key*t + key[:r]
    elif len2 > len1:
        key = key[:len1]
    letter_list = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    c_list = []
    p_list = []
    k_list = []
    p_list.extend(plain)
    k_list.extend(key)
#    print(len(plain))
#    print(len(key))
    for i in range(len(key)):
        if p_list[i] not in letter_list:
            c_list.append(p_list[i])
        else:
            p = letter_list.index(p_list[i])
            k = letter_list.index(k_list[i])
            c = (p+k)%52
            c_list.append(letter_list[c])
    cipher = ''.join(c_list)
    return cipher

def vigenere_decrypt(cipher, key):
    # To do
    len1 = len(cipher)
    len2 = len(key)
    if len2 < len1:
        t = len1//len2 #times
        r = len1%len2 #remainer
        key = key*t + key[:r]
    elif len2 > len1:
        key = key[:len1]
    c_list = []
    p_list = []
    k_list = []
    letter_list = ['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z','a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']
    c_list.extend(cipher)
    k_list.extend(key)
    for i in range(len(key)):
        if c_list[i] not in letter_list:
            p_list.append(c_list[i])
        else:
            c = letter_list.index(c_list[i])
            k = letter_list.index(k_list[i])
            p = (c-k)%52
            p_list.append(letter_list[p])
    plain = ''.join(p_list)
    return plain
#############Class####################################
class ClientSM:
    def __init__(self, s):
        self.state = S_OFFLINE
        self.peer = ''
        self.me = ''
        self.out_msg = ''
        self.s = s

    def set_state(self, state):
        self.state = state

    def get_state(self):
        return self.state

    def set_myname(self, name):
        self.me = name

    def get_myname(self):
        return self.me

    def connect_to(self, peer):
        msg = json.dumps({"action":"connect", "target":peer})
        mysend(self.s, msg)
        response = json.loads(myrecv(self.s))
        if response["status"] == "success":
            self.peer = peer
            self.out_msg += 'You are connected with '+ self.peer + '\n'
            return (True)
        elif response["status"] == "busy":
            self.out_msg += 'User is busy. Please try again later\n'
        elif response["status"] == "self":
            self.out_msg += 'Cannot talk to yourself (sick)\n'
        else:
            self.out_msg += 'User is not online, try again later\n'
        return(False)

    def disconnect(self):
        msg = json.dumps({"action":"disconnect"})
        mysend(self.s, msg)
        self.out_msg += 'You are disconnected from ' + self.peer + '\n'
        self.peer = ''

    def proc(self, my_msg, peer_msg):
        self.out_msg = ''
#==============================================================================
# Once logged in, do a few things: get peer listing, connect, search
# And, of course, if you are so bored, just go
# This is event handling instate "S_LOGGEDIN"
#==============================================================================
        if self.state == S_LOGGEDIN:
            # todo: can't deal with multiple lines yet
            if len(my_msg) > 0:

                if my_msg == 'q':
                    self.out_msg += 'See you next time!\n'
                    self.state = S_OFFLINE

                elif my_msg == 'time':
                    mysend(self.s, json.dumps({"action":"time"}))
                    time_in = json.loads(myrecv(self.s))["results"]
                    self.out_msg += "Time is: " + time_in

                elif my_msg == 'who':
                    mysend(self.s, json.dumps({"action":"list"}))
                    logged_in = json.loads(myrecv(self.s))["results"]
                    self.out_msg += 'Here are all the users in the system:\n'
                    self.out_msg += logged_in

                elif my_msg[0] == 'c':
                    peer = my_msg[1:]
                    peer = peer.strip()
                    if self.connect_to(peer) == True:
                        self.state = S_CHATTING
                        self.out_msg += 'Connect to ' + peer + '. Chat away!\n\n'
                        self.out_msg += '-----------------------------------\n'
                    else:
                        self.out_msg += 'Connection unsuccessful\n'

                elif my_msg[0] == '?':
                    oldTerm = my_msg[1:].strip()
                    term = vigenere_encrypt(oldTerm, key)
                    mysend(self.s, json.dumps({"action":"search", "target":term}))
                    search_rslt = json.loads(myrecv(self.s))["results"]
                    if (len(search_rslt)) > 0:
                        #find the second colon
                        lst = []
                        for each in search_rslt:
                            count = 0
                            for i in range(len(each)):
                                if each[i] == ":":
                                    count+=1
                                if count == 2:
                                    deciphered = each[:i+2]+vigenere_decrypt(each[i+2:],key)
                                    lst.append(deciphered)
                                    break
                        search_rslt = "\n".join(lst)
                        self.out_msg += search_rslt + "\n\n"
                    else:
                        self.out_msg += '\'' + oldTerm + '\'' + ' not found\n\n'

                elif my_msg[0] == 'p' and my_msg[1:].isdigit():
                    poem_idx = my_msg[1:].strip()
                    mysend(self.s, json.dumps({"action":"poem", "target":poem_idx}))
                    poem = json.loads(myrecv(self.s))["results"]
                    if (len(poem) > 0):
                        self.out_msg += poem + '\n\n'
                    else:
                        self.out_msg += 'Sonnet ' + poem_idx + ' not found\n\n'
                
                elif my_msg == 'game':
                    self.state = S_GAMING
                
                elif my_msg == "score":
                    mysend(self.s,json.dumps({"action":"scores"}))
                    score_dic = json.loads(myrecv(self.s))
                    if score_dic == {}:
                        self.out_msg += "No one plays yet\n"
                    else:
                        for k in score_dic:
                            self.out_msg += k + " : " + str(score_dic[k]) + " s\n"

                else:
                    self.out_msg += menu

            if len(peer_msg) > 0:
                try:
                    peer_msg = json.loads(peer_msg)
                except Exception as err :
                    self.out_msg += " json.loads failed " + str(err)
                    return self.out_msg

                if peer_msg["action"] == "connect":
                    # ----------your code here------#
                    print(peer_msg)
                    self.peer = peer_msg["from"]
                    self.out_msg += 'Request from ' + self.peer + '\n'
                    self.out_msg += 'You are connected with ' + self.peer
                    self.out_msg += '. Chat away!\n\n'
                    self.out_msg += '------------------------------------\n'
                    self.state = S_CHATTING
                    # ----------end of your code----#

#==============================================================================
# Start chatting, 'bye' for quit
# This is event handling instate "S_CHATTING"
#==============================================================================
        elif self.state == S_CHATTING:
            if len(my_msg) > 0:     # my stuff going out
                mysend(self.s, json.dumps({"action":"exchange", "from":"[" + self.me + "]", "message":vigenere_encrypt(my_msg,key)}))
                if my_msg == 'bye':
                    self.disconnect()
                    self.state = S_LOGGEDIN
                    self.peer = ''
            if len(peer_msg) > 0:  # peer's stuff, coming in
                # ----------your code here------#
                peer_msg = json.loads(peer_msg)
                if peer_msg["action"] == "connect":
                    self.out_msg += "(" + peer_msg["from"] + " joined)\n"
                elif peer_msg["action"] == "disconnect":
                    self.out_msg += peer_msg["message"]
                    self.state = S_LOGGEDIN
                else:
                    self.out_msg += peer_msg["from"] + vigenere_decrypt(peer_msg["message"],key)
                # ----------end of your code----#
            if self.state == S_LOGGEDIN:
                # Display the menu again
                self.out_msg += menu
# =============================================================================
# gaming state
# =============================================================================
        elif self.state == S_GAMING:
            import game
            time = round(game.totalTime)
            mysend(self.s, json.dumps({"action":"gameover","score":time}))
            self.state = S_LOGGEDIN
                
#==============================================================================
# invalid state
#==============================================================================
        else:
            self.out_msg += 'How did you wind up here??\n'
            print_state(self.state)

        return self.out_msg
