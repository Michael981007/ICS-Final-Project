import time
import socket
import select
import sys
import json
from chat_utils import *
import client_state_machine as csm
import threading
from tkinter import *


def Main():
    main_frame = Tk()
    main_frame.title('Python Chat System')
    main_frame.configure(width=120, height=120)
    
    #----------------------message box----------------------------------------
#   background = Frame(main_frame, width=70, height=70, bg='white')
    message_text = Text(main_frame, relief=GROOVE, bg="white", width = 40,height=20,  highlightcolor="white", highlightthickness=1,borderwidth=2)
    message_text.grid(row=0, column=0, sticky=W + E + N + S, padx=(10, 30))
    message_text.config(state = 'normal')
    #message_text.insert(INSERT, self.system_msg + '\n')#here, problem
    #message_text.insert(INSERT, send_msg.get() + '\n')#here, i need to receive from other clients
    message_text.config(state='disable')

    '''
    msg_sc_bar = Scrollbar(main_frame)
    msg_sc_bar.grid(row=1, column=0, sticky=N + S + E, rowspan=3, pady=(0, 5))
    msg_sc_bar["command"] = message_text.yview
    message_text["yscrollcommand"] = msg_sc_bar.set
    '''
    #-------------------entry box---------------------------------------------
    #isSent = False
    send_msg = StringVar()
    entry_box = Entry(main_frame, textvariable = send_msg, width = 25, bg = 'white').place(x=12, y=300)
    final_msg = []


    #-------------------send button-------------------------------------------

    def send_it():
#        print(str(send_msg.get()))
#        sys.stdout.write(str(send_msg.get()))
#        print(sys.stdin.readline())
        message_text.config(state = 'normal')
        message_text.insert(INSERT, '\n' + str(send_msg.get()) + '\n')
        message_text.config(state = 'disable')
        final_msg.append(str(send_msg.get()))
        #isSent = True



    def clear_it():
        entry_box.delete(0, END)

    send = Button(main_frame, text='Send', width = 4, height = 1, background = 'white', command = send_it).place(x=250, y=300)
    clear = Button(main_frame, text='Clear', width = 4, height = 1, background = 'white', command = clear_it).place(x=300, y=300)
    quit = Button(main_frame, text='Quit', width = 4, height = 1, background = 'white', command = main_frame.destroy).place(x=150, y=340)


    c = Client(message_text, final_msg,args=None)
#    isSent = False
    t = threading.Thread(target=c.run_chat)
    t.start()
    main_frame.mainloop()



#class name need modify
class Client:
    #class self need modify
    def __init__(self, message_text, final_msg, args = None):
        self.peer = ''
        self.console_input = []
        self.state = S_OFFLINE
        self.system_msg = ''
        self.local_msg = ''
        self.peer_msg = ''
        self.args = args
        self.msg_box = message_text
        self.final_msg = final_msg

        #self.isSent = isSent


        #-------------------------


    # modify this part later
    '''
    def displayInGUI(self, msg: string):
        self.panel.displaySth2Panel(msg)
    '''

    def quit(self):
        self.socket.shutdown(socket.SHUT_RDWR)
        self.socket.close()

    def get_name(self):
        return self.name

    def init_chat(self):
        self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM )
        svr = SERVER #if self.args.d == None else (self.args.d, CHAT_PORT)
        self.socket.connect(svr)
        self.sm = csm.ClientSM(self.socket)
        
        reading_thread = threading.Thread(target=self.read_input)
        reading_thread.daemon = True
        reading_thread.start()

    def shutdown_chat(self):
        return

    def send(self, msg):
        mysend(self.socket, msg)

    def recv(self):
        return myrecv(self.socket)

    def get_msgs(self):
        read, write, error = select.select([self.socket], [], [], 0)
        my_msg = ''
        peer_msg = []
        #peer_code = M_UNDEF    for json data, peer_code is redundant
        if len(self.console_input) > 0:

            my_msg = self.console_input.pop(0)
        #if self.isSent:

#        my_msg = self.send_msg.get()


        if self.socket in read:
            peer_msg = self.recv()
        return my_msg, peer_msg

    def output(self):
        #this part should not be changed until I can call out the GUI panel
        if len(self.system_msg) > 0:
            print(self.system_msg)
            self.msg_box.config(state = 'normal')
            self.msg_box.insert(INSERT, self.system_msg + '\n')
            self.msg_box.config(state = 'disable')
            self.system_msg = ''


    def login(self):
        my_msg, peer_msg = self.get_msgs()
#        print(my_msg)
        if len(my_msg) > 0:
            self.name = my_msg
            msg = json.dumps({"action":"login", "name":self.name})
            self.send(msg)
            response = json.loads(self.recv())
#            print("my name ok")
            if response["status"] == 'ok':
                self.state = S_LOGGEDIN
                self.sm.set_state(S_LOGGEDIN)
                self.sm.set_myname(self.name)
                self.print_instructions()
                return (True)
            elif response["status"] == 'duplicate':
                self.system_msg += 'Duplicate username, try again'
                return False
        else:               # fix: dup is only one of the reasons
           return(False)

    #here need change

    def read_input(self):
        while True:
            if self.final_msg != []: 
                self.console_input.append(self.final_msg.pop()) 
                
#            print(text)


    def print_instructions(self):
        self.system_msg += menu

    def run_chat(self):
        self.init_chat()
        self.system_msg += 'Welcome to ICS chat\n'
        self.system_msg += 'Please enter your name: '
        
        self.output()

#        self.msg_box.config(state = 'normal')
#        self.msg_box.insert(INSERT, self.system_msg + '\n')
#        self.msg_box.config(state = 'disable')

#        self.output()
#        system_msg = ''
        while self.login() != True:
            self.output()
#            print("Not ok")
        self.system_msg += 'Welcome, ' + self.get_name() + '!'
        self.output()
        while self.sm.get_state() != S_OFFLINE:
            self.proc()
            self.output()
            time.sleep(CHAT_WAIT)
        self.quit()

#==============================================================================
# main processing loop
#==============================================================================
    def proc(self):
        my_msg, peer_msg = self.get_msgs()
        self.system_msg += self.sm.proc(my_msg, peer_msg)
        #insert msystem msg to msg_box
        #--------------------------------------------------
#        self.msg_box.config(state = 'normal')
#        self.msg_box.insert(INSERT, self.system_msg + '\n')
#        self.msg_box.config(state = 'disable')




Main()